let currentCategory = '1000';
let isascending = false;
let sortedData = [];

const filterVideo = (val) => {
  currentCategory = val;  
  LoadData(val);
};


const sortData = (dt, isascending = true) => {
  const AllVideos = document.getElementById("all-videos");
  const sorted =Array.from(AllVideos.children)
  console.log(sorted);
  const sortedCards = sorted.sort((a, b) => {
    const viewsA = parseInt(a.getAttribute('data-views'));
    const viewsB = parseInt(b.getAttribute('data-views'));

    return viewsB - viewsA;

});
AllVideos.innerHTML = '';
sortedCards.forEach((card) => {
    AllVideos.appendChild(card);
});
console.log(sortedCards);

};


// loadData here...........................
const LoadData = (val) => {
  fetch(`https://openapi.programming-hero.com/api/videos/category/${val}`)
    .then((res) => res.json())
    .then((dt) => displaydata(dt.data));
};

const displaydata = (dt) => {
  const AllVideos = document.getElementById("all-videos");
  AllVideos.innerHTML = '';

  if (dt.length === 0) {
    const helloWorldMessage = document.createElement("p");
    helloWorldMessage.classList.add("im");
    helloWorldMessage.innerHTML = `
      <img class="im-img" src="./icon.png" alt="">
      <h2>Oops! Sorry, there is no </br> content here</h2>
    `;
    AllVideos.appendChild(helloWorldMessage);
  } else {
    dt.forEach((item) => {
      const card = document.createElement("div");
      card.classList.add("box");
      card.setAttribute('data-views',item.others.views)

      card.innerHTML = `
        <div class="thumb-time">
            <img class="box-img" src=${item.thumbnail} alt="">
            <h6>${convertTime(item?.others.posted_date)}</h6>
        </div>

        <div class="center-box">
          <img class="profile-img" src=${item?.authors[0].profile_picture} alt="">
          <h3>${item?.title}</h3>
        </div>
        <p>${item?.authors[0].profile_name} ${
        item?.authors[0].verified
          ? '<img class="badge-icon" src="./verified.png" alt="" />'
          : ""
      }</p>

        <p>${item?.others.views}</p>
      `;

      AllVideos.appendChild(card);
    });
  }
};

const convertTime = (val) => {
  let hours = Math.floor(val / 60);
  let minute = val % 60;
  if (hours === 0 && minute === 0) {
    return ` `;
  }
  return `${hours} hours :  ${minute} minutes`
}

LoadData(currentCategory);
sortData(currentCategory);  // Corrected function name from sortByViews to sortData
